'use client'
import React, { useState, useEffect } from 'react'
import { isLogin, openLoginModal, } from '@/utils/helpers';
import { translate } from '@/utils/translation';
import { useSelector } from 'react-redux';
import { userDataSelector } from '../store/reducers/userReducer';
import { getCommentsByNewsApi, setCommentApi } from '@/utils/api/api';
import toast from 'react-hot-toast';
import CommentCard from './CommentCard';
import { currentLanguageSelector } from '../store/reducers/languageReducer';
import { setLoginModalState } from '../store/reducers/helperReducer';
import LoadMoreSpinner from '../commonComponents/loadermoreBtn/LoaderSpinner';

const CommentSection = ({ newsId, isCommentEnabled }) => {

    const userData = useSelector(userDataSelector)
    const currentLanguage = useSelector(currentLanguageSelector)
    const [comment, setComment] = useState('')
    const [replied, setReplied] = useState(true)
    const [commentsData, setCommentsData] = useState([])
    const [isLoading, setIsLoading] = useState(false)
    const [commentId, setCommentId] = useState(null)

    const [isSubmitting, setIsSubmitting] = useState(false)




    const getCommentByNews = async () => {
        setIsLoading(true)
        try {
            const { data } = await getCommentsByNewsApi.getCommentsByNews({
                news_id: newsId,
                offset: '0',
                limit: '10'
            });

            const commentData = data?.data?.data;

            setCommentsData(commentData ? commentData : [])
            setIsLoading(false)
            return commentData ? commentData : [];
        } catch (error) {
            console.log(error);
        }
    };


    const setNewComment = async (e) => {
        e.preventDefault();

        if (isCommentEnabled === 0) {
            toast.error(translate('disabledCommentsMsg'));
            return;
        }
        if (!isLogin()) {
            setLoginModalState({ openModal: true })
            toast.error(translate('loginFirst'));
            setTimeout(() => {
                setLoginModalState({ openModal: false })
            }, 2000);
            return;
        }
        if (comment.trim() === '' && !comment) {
            toast.error(translate('commentRequired'))
            return;
        }
        if (comment && comment.trim() !== '') {
            setIsSubmitting(true)
            try {
                const response = await setCommentApi.setCommnet({
                    language_code: currentLanguage?.code,
                    parent_id: 0,
                    news_id: newsId,
                    message: comment
                });
                setComment('');
                getCommentByNews()
                setReplied(true)
                setTimeout(() => {
                    setIsSubmitting(false)
                }, 1000);

            } catch (error) {
                console.error('Error:', error);
            }
        }
        else {
            toast.error(translate('commentRequired'))
        }
    };

    useEffect(() => {
        if (newsId) {
            getCommentByNews()
        }
    }, [newsId])

    useEffect(() => {
    }, [commentsData])



    return (
        <section className='commentSect mt-8'>

            {/* post commetSect */}
            <form className='flex flex-col gap-4' onSubmit={e => setNewComment(e)}>
                <div>
                    <span className='textPrimary text-[24px] md:text-[34px] font-[600]'>{translate('leaveacomments')}</span>
                </div>
                <div>
                    <textarea value={comment} onChange={(e) => setComment(e.target.value)} name="comment" id="comment" cols="30" rows="10" className='w-full p-3 commonBg border borderColor commonRadius textPrimary' placeholder={`${translate('shareThoghtLbl')}`}></textarea>
                </div>
                <div className='flex justify-end'>
                    {
                        isSubmitting ?
                            <button className='commonBtn text-[18px] md:text-[22px]'>{<LoadMoreSpinner />}</button>
                            :
                            <button type='submit' className='commonBtn text-[18px] md:text-[22px]'>{translate('submitBtn')}</button>
                    }

                </div>
            </form>


            {/* commentsView Sect */}
            {
                // userData && userData?.data &&
                <div className='commentsView flex flex-col gap-4'>
                    {
                        commentsData?.length > 0 &&
                        <div>
                            <h3 className='textPrimary text-[24px] md:text-[34px] font-[600]'>{translate('comment')}</h3>
                        </div>
                    }
                    {
                        commentsData?.map((element) => {
                            return <div className='flex flex-col gap-6' key={element?.id} onClick={() => setCommentId(element?.id)}>
                                {/* Comment */}
                                <div className='w-full'>
                                    <CommentCard isLoading={isLoading} element={element} getCommentByNews={getCommentByNews} newsId={newsId} isCommentEnabled={isCommentEnabled} />
                                </div>

                                {/* CommentReply */}
                                {
                                    element?.reply?.map((ele) => {
                                        return <div className='flex items-center justify-end' key={ele?.id} onClick={() => setCommentId(ele?.id)}>
                                            <CommentCard repliedCard={true} isLoading={isLoading} element={ele} getCommentByNews={getCommentByNews} newsId={newsId} isCommentEnabled={isCommentEnabled} />
                                        </div>
                                    })
                                }

                            </div>
                        })
                    }

                </div>
            }

        </section>
    )
}

export default CommentSection