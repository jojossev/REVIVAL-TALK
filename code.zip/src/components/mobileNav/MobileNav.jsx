'use client'
import React, { useState } from 'react'
import { IoReorderThree } from "react-icons/io5";
import ProfileDropdown from '../dropdowns/ProfileDropdown';
import LanguageDropdown from '../dropdowns/LanguageDropdown';
import ThemeToggler from '../topBar/ThemeToggler';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSelector } from 'react-redux';
import { settingsSelector } from '../store/reducers/settingsReducer';
import { checkNewsDataSelector } from '../store/reducers/CheckNewsDataReducer';
import MorePagesDropdown from '../dropdowns/MorePagesDropdown';
import { languagesListSelector } from '../store/reducers/languageReducer';
import { currentLangCode, defaultLanguageCode, isLogin, setCateOffset, } from '@/utils/helpers';
import { translate } from '@/utils/translation';
import { userDataSelector } from '../store/reducers/userReducer';
import LoginModal from '../auth/LoginModal';
import SearchModal from '../search/SearchModal';
import {
    Sheet,
    SheetContent,
    SheetTrigger,
} from "@/components/ui/sheet"
import { FaAngleDown, FaAngleUp } from 'react-icons/fa'
import { categoriesSelector, categoryLimit, totalCates } from '../store/reducers/CategoriesReducer';

import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const MobileNav = ({ userRole, handleAlert, totalMorePages, morePagesOffset, setMorePagesOffset, setIsLoadMorePages, morePagesLimit }) => {

    const currLangCode = currentLangCode();
    const defaultLangCode = defaultLanguageCode();

    const userData = useSelector(userDataSelector)
    const languagesData = useSelector(languagesListSelector)
    const settingsData = useSelector(settingsSelector);

    const checkNewsData = useSelector(checkNewsDataSelector);
    const showLiveNewsPage = settingsData && settingsData?.data?.live_streaming_mode === '1' && checkNewsData && checkNewsData?.data?.isLiveNewsData;
    const showBreakingNewsPage = settingsData && settingsData?.data?.breaking_news_mode === '1' && checkNewsData && checkNewsData?.data?.isBreakingNewsData;
    const showRssFeed = settingsData && settingsData?.data?.rss_feed_mode === '1';

    const showAboutContactUs = !showBreakingNewsPage && !showLiveNewsPage;

    const categories = useSelector(categoriesSelector);
    const cateLimit = useSelector(categoryLimit);
    const totalCategories = useSelector(totalCates);

    const [isMenuOpen, setIsMenuOpen] = useState(true);
    let userName = '';

    const checkUserData = userData => {
        if (userData?.data && userData?.data?.name !== '') {
            return (userName = userData?.data?.name)
        } else if (userData?.data && userData?.data?.email !== '') {
            return (userName = userData?.data?.email)
        } else if (userData?.data && (userData?.data?.mobile !== null || userData?.data?.mobile !== '')) {
            return (userName = userData?.data?.mobile)
        }
    }


    const router = usePathname()

    const [open, setOpen] = useState(false);
    const showDrawer = () => {
        setOpen(true);
    };
    const onClose = () => {
        setOpen(false);
    };

    return (
        <div>
            <Sheet>
                <SheetTrigger asChild>
                    <span onClick={showDrawer} className='dark:text-white cursor-pointer'><IoReorderThree size={44} /></span>
                </SheetTrigger>
                <SheetContent onOpenChange={onClose} open={open} className='!bodyBgColor overflow-y-scroll'>
                    <div className='flex flex-col gap-6 mt-6'>
                        <div className='flex items-center gap-6 flex-wrap'>
                            {
                                isLogin() && checkUserData(userData) ?
                                    <ProfileDropdown userName={userName} userRole={userRole} handleAlert={handleAlert} onClose={onClose} mobileNav={true} />
                                    :
                                    <LoginModal onClose={onClose} />
                            }
                            <ThemeToggler mobileNav={true} />

                        </div>
                        <div className='flex items-center gap-6 flex-wrap'>
                            {
                                router === `/${currLangCode ? currLangCode : defaultLangCode}` && languagesData?.length > 1 &&
                                <LanguageDropdown mobileNav={true} onClose={onClose} setMorePagesOffset={setMorePagesOffset} setIsLoadMorePages={setIsLoadMorePages} />
                            }
                            <div>
                                <SearchModal onClose={onClose} />
                            </div>
                        </div>
                        <div className="navLinks">
                            <ul className='flex flex-col gap-3'>

                                <li className='list-none'>
                                    <Link href={`/${currLangCode ? currLangCode : defaultLangCode}`} title={translate('home')} className={`${router === `/${currLangCode ? currLangCode : defaultLangCode}` ? 'activeLink after:h-[94%]' : ''} relative after:content-[""] after:absolute after:top-[1px] after:-left-[8px] after:h-[0%] after:w-[4px] after:rounded-full after:primaryBg hover:primaryColor transition-all duration-500 hover:after:h-[94%] hover:after:transition-all hover:after:duration-[0.3s]  textPrimary uppercase font-[500]`} onClick={onClose}>{translate('home')}</Link>
                                </li>

                                {
                                    showAboutContactUs &&
                                    <li className='list-none'>
                                        <Link href={`/${currLangCode}/about-us`} className={`${router === `/${currLangCode}/about-us` ? 'activeLink after:h-[94%]' : ''} relative after:content-[""] after:absolute after:top-[1px] after:-left-[8px] after:h-[0%] after:w-[4px] after:rounded-full after:primaryBg hover:primaryColor transition-all duration-500 hover:after:h-[94%] hover:after:transition-all hover:after:duration-[0.3s]  textPrimary uppercase font-[500]`} onClick={onClose} title={translate('aboutus')}>{translate('aboutus')}</Link>
                                    </li>
                                }

                                {
                                    showLiveNewsPage &&
                                    <li className='list-none'>
                                        <Link href={`/${currLangCode}/live-news`} className={`${router === `/${currLangCode}/live-news` ? 'activeLink after:h-[94%]' : ''} relative after:content-[""] after:absolute after:top-[1px] after:-left-[8px] after:h-[0%] after:w-[4px] after:rounded-full after:primaryBg hover:primaryColor transition-all duration-500 hover:after:h-[94%] hover:after:transition-all hover:after:duration-[0.3s]  textPrimary uppercase font-[500]`} onClick={onClose} title={translate('livenews')}>{translate('livenews')}</Link>
                                    </li>
                                }

                                {
                                    showBreakingNewsPage &&
                                    <li className='list-none'>
                                        <Link href={`/${currLangCode}/all-breaking-news`} className={`${router === `/${currLangCode}/all-breaking-news` ? 'activeLink after:h-[94%]' : ''} relative after:content-[""] after:absolute after:top-[1px] after:-left-[8px] after:h-[0%] after:w-[4px] after:rounded-full after:primaryBg hover:primaryColor transition-all duration-500 hover:after:h-[94%] hover:after:transition-all hover:after:duration-[0.3s]  textPrimary uppercase font-[500]`} onClick={onClose} title={translate('breakingnews')}>{translate('breakingnews')}</Link>
                                    </li>
                                }

                                <li className='list-none'>
                                    <Link href={`/${currLangCode}/video-news`} className={`${router === `/${currLangCode}/video-news` ? 'activeLink after:h-[94%]' : ''} relative after:content-[""] after:absolute after:top-[1px] after:-left-[8px] after:h-[0%] after:w-[4px] after:rounded-full after:primaryBg hover:primaryColor transition-all duration-500 hover:after:h-[94%] hover:after:transition-all hover:after:duration-[0.3s]  textPrimary uppercase font-[500]`} onClick={onClose} title={translate('videosLbl')}>{translate('videosLbl')}</Link>
                                </li>

                                {
                                    showRssFeed &&
                                    <li className='list-none'>
                                        <Link href={`/${currLangCode}/rss-feed`} className={`${router === `/${currLangCode}/rss-feed` ? 'activeLink after:h-[94%]' : ''} relative after:content-[""] after:absolute after:top-[1px] after:-left-[8px] after:h-[0%] after:w-[4px] after:rounded-full after:primaryBg hover:primaryColor transition-all duration-500 hover:after:h-[94%] hover:after:transition-all hover:after:duration-[0.3s]  textPrimary uppercase font-[500]`} onClick={onClose} title={translate('rssFeed')}>{translate('rssFeed')}</Link>
                                    </li>
                                }

                                {
                                    showAboutContactUs &&
                                    <li className='list-none'>
                                        <Link href={`/${currLangCode}/contact-us`} className={`${router === `/${currLangCode}/contact-us` ? 'activeLink after:h-[94%]' : ''} relative after:content-[""] after:absolute after:top-[1px] after:-left-[8px] after:h-[0%] after:w-[4px] after:rounded-full after:primaryBg hover:primaryColor transition-all duration-500 hover:after:h-[94%] hover:after:transition-all hover:after:duration-[0.3s]  textPrimary uppercase font-[500]`} onClick={onClose} title={translate('contactus')}>{translate('contactus')}</Link>
                                    </li>
                                }

                                <li className='list-none'>
                                    <Link href={`/${currLangCode}/enews`} className={`${router === `/${currLangCode}/enews` ? 'activeLink after:h-[94%]' : ''} relative after:content-[""] after:absolute after:top-[1px] after:-left-[8px] after:h-[0%] after:w-[4px] after:rounded-full after:primaryBg hover:primaryColor transition-all duration-500 hover:after:h-[94%] hover:after:transition-all hover:after:duration-[0.3s]  textPrimary uppercase font-[500]`} onClick={onClose} title={translate('e_news')}>{translate('e_news')}</Link>
                                </li>

                                <li className='list-none'>
                                    <MorePagesDropdown onClose={onClose} totalMorePages={totalMorePages} morePagesOffset={morePagesOffset} setMorePagesOffset={setMorePagesOffset} setIsLoadMorePages={setIsLoadMorePages} morePagesLimit={morePagesLimit} />
                                </li>

                            </ul>
                        </div>

                        {
                            categories?.length > 0 && settingsData?.data?.category_mode === '1' &&
                            <div className='relative'>
                                <div className={`flex items-center justify-between text-lg textPrimary font-[700] cursor-pointer`} onClick={() => setIsMenuOpen(isMenuOpen ? false : true)}>
                                    <h1>{translate('categories')}</h1>
                                    <span className='primaryBg p-2 rounded-full text-white flexCenter'>
                                        {isMenuOpen ? <FaAngleUp /> : <FaAngleDown />}
                                    </span>
                                </div>
                                {
                                    isMenuOpen &&
                                    <div className='otherCats mobileCates overflow-y-scroll max-h-[344px] pb-6 flex flex-col gap-3  absolute bg-transparent textPrimary w-full mt-[12px]'>
                                        {
                                            categories?.map((element) =>
                                            (
                                                element?.sub_categories?.length > 0 && settingsData?.data?.subcategory_mode === '1' ?
                                                    <div key={element?.id}>
                                                        <DropdownMenu>
                                                            <DropdownMenuTrigger className='bg-transparent dropdownTrigg p-0 h-max w-max flex items-center gap-1 cursor-pointer data-[state=closed]:[&>svg]:rotate-0 data-[state=open]:[&>svg]:rotate-180 transition-all duration-300'>
                                                                <span className='textPrimary font-[600] flex items-center gap-1 cursor-pointer'>
                                                                    {element.category_name}
                                                                </span>
                                                                <span className='opacity-80'>
                                                                    <FaAngleDown />
                                                                </span>
                                                            </DropdownMenuTrigger>
                                                            <DropdownMenuContent className='w-full bg-white relative h-[180px] sm:h-[250px] overflow-y-scroll' side='bottom' align='start'>
                                                                <div className='bg-white flex flex-col gap-3 !w-full max-w-full'>
                                                                    {element.sub_categories.map((data, index) => (
                                                                        <DropdownMenuItem key={index} className='hover:!bg-transparent'>
                                                                            <Link
                                                                                // key={index}
                                                                                href={`/${currLangCode}/categories-news/sub-category/${data?.slug}`}
                                                                                title={data.subcategory_name}
                                                                                onClick={() => setIsMenuOpen(false)}
                                                                                className='cursor-pointer w-max !max-w-full relative after:content-[""] after:absolute after:top-[1px] after:-left-[8px] after:h-[0%] after:w-[4px] after:rounded-full after:primaryBg hover:primaryColor transition-all duration-500 hover:after:h-[88%] hover:after:transition-all hover:after:duration-[0.3s] text-black font-[600]'
                                                                            >
                                                                                {data.subcategory_name}
                                                                            </Link>
                                                                        </DropdownMenuItem>
                                                                    ))}
                                                                </div>
                                                            </DropdownMenuContent>
                                                        </DropdownMenu>
                                                    </div>

                                                    :
                                                    <Link key={element?.slug}
                                                        href={`/${currLangCode}/categories-news/${element?.slug}`}
                                                        onClick={() => setIsMenuOpen(false)}
                                                        title={element?.category_name} className='textPrimary font-[600]'>{element?.category_name}
                                                    </Link>

                                            )
                                            )
                                        }
                                        {
                                            totalCategories > cateLimit && totalCategories !== categories?.length &&
                                            <span onClick={() => setCateOffset(1)} className='primaryColor font-[600] text-center cursor-pointer'>{translate('loadMore')}</span>
                                        }
                                    </div>
                                }
                            </div>
                        }


                    </div>
                </SheetContent>
            </Sheet>
        </div >
    )
}

export default MobileNav